"""Run with FreeCAD's Python: python make_p03.py [output.FCStd] [pitch_mm]."""
import sys
from pathlib import Path
import FreeCAD as App
import Part
from fcstd_view import set_initial_view

V = App.Vector

def build(path, pitch=24):
    doc = App.newDocument('Saddle')
    params = doc.addObject('App::VarSet', 'Dimensions')
    params.addProperty('App::PropertyLength','TopPitch','Mounting','Centre distance between X columns')
    params.TopPitch = pitch

    def box(name, width, height, z):
        obj = doc.addObject('Part::Box', name)
        obj.Length, obj.Width, obj.Height = 40, width, height
        obj.Placement.Base = V(0, -width/2, z)
        return obj

    foot = box('LowerBlock', 56, 22, 0)
    wing = box('UpperWing', 66, 6, 22)
    blank = doc.addObject('Part::Fuse', 'Blank')
    blank.Base, blank.Tool, blank.Refine = foot, wing, True
    foot.Visibility = wing.Visibility = False

    def bore(name, radius, depth, base, direction):
        obj = doc.addObject('Part::Cylinder', name)
        obj.Radius, obj.Height = radius, depth
        obj.Placement = App.Placement(V(*base), App.Rotation(V(0,0,1), V(*direction)))
        return obj

    bores = [bore('NutBore', 11.1, 40, (0,0,12), (1,0,0))]
    for i, y in enumerate((-21,21)):
        bores.append(bore('Guide'+str(i+1), 4.2, 40, (0,y,12), (1,0,0)))
    for i, (y,z) in enumerate(((-12,3),(12,21))):
        bores.append(bore('FlangeM3_'+str(i+1), 1.5, 8, (0,y,z), (1,0,0)))
    for col, sign in enumerate(('-', '+')):
        for row, y in enumerate((-24,24)):
            hole = bore(f'TopM5_{col+1}{row+1}', 2.5, 6, (20,y,22), (0,0,1))
            hole.setExpression('Placement.Base.x', f'20 mm {sign} Dimensions.TopPitch / 2')
            bores.append(hole)
    base = blank
    for i, hole in enumerate(bores):
        result = doc.addObject('Part::Cut', 'SaddleResult' if i==len(bores)-1 else f'Drill{i+1}')
        result.Base, result.Tool, result.Refine = base, hole, True
        base.Visibility = hole.Visibility = False
        base = result
    doc.recompute()
    assert len(result.Shape.Solids)==1 and result.Shape.isValid()
    doc.saveAs(str(Path(path).resolve()))
    set_initial_view(path,(20,0,14),88)
    return doc

if __name__=='__main__':
    dest=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('P03.FCStd')
    build(dest,float(sys.argv[2]) if len(sys.argv)>2 else 24)
