"""Persist visibility and an initial axonometric view for headlessly authored FCStd."""
import math
import xml.etree.ElementTree as ET
from zipfile import ZipFile, ZIP_DEFLATED

def set_initial_view(path, centre, height):
    with ZipFile(path,'a',compression=ZIP_DEFLATED) as archive:
        # Interactive FreeCAD supplies its own native view providers.
        if 'GuiDocument.xml' in archive.namelist():
            return
        model=ET.fromstring(archive.read('Document.xml'))
        gui=ET.Element('Document',{'SchemaVersion':'1','HasExpansion':'1'})
        ET.SubElement(gui,'Expand')
        objects=model.findall('./ObjectData/Object')
        views=ET.SubElement(gui,'ViewProviderData',Count=str(len(objects)))
        for i,obj in enumerate(objects):
            view=ET.SubElement(views,'ViewProvider',name=obj.get('name'),expanded='0',treeRank=str(i*100))
            props=ET.SubElement(view,'Properties',Count='1')
            prop=ET.SubElement(props,'Property',name='Visibility',type='App::PropertyBool',status='1')
            saved=obj.find("./Properties/Property[@name='Visibility']/Bool")
            ET.SubElement(prop,'Bool',value=saved.get('value') if saved is not None else 'true')
        distance=height*2.5
        pos=[c+v*distance/math.sqrt(3) for c,v in zip(centre,(-1,-1,1))]
        settings=('OrthographicCamera {\n  viewportMapping ADJUST_CAMERA\n'
                  f'  position {pos[0]} {pos[1]} {pos[2]}\n'
                  '  orientation 0.74290606 -0.30772176 -0.59447280 1.2171160\n'
                  f'  nearDistance {distance-height}\n  farDistance {distance+height}\n'
                  f'  aspectRatio 1\n  focalDistance {distance}\n  height {height}\n}}\n')
        ET.SubElement(gui,'Camera',settings=settings)
        archive.writestr('GuiDocument.xml',ET.tostring(gui,encoding='utf-8',xml_declaration=True))
