"""Build the independent native-expression assembly from released part models."""
import itertools, json, shutil, tempfile
from pathlib import Path
import FreeCAD as A, Part
from fcstd_view import set_initial_view

sub=Path(__file__).resolve().parent
V=A.Vector
shapes={}
for n in ('P01','P05','P06','P07','P08','P10','P11'):
    shapes[n]=Part.read(str(sub/'released'/(n+'.step')))
for n in ('P02','P03','P04','P09'):
    src=A.openDocument(str(sub/(n+'.FCStd')))
    visible=[o for o in src.Objects if hasattr(o,'Shape') and o.Visibility and not o.Shape.isNull()]
    assert len(visible)==1,(n,[o.Name for o in visible])
    shapes[n]=Part.makeCompound([visible[0].Shape.copy()])
    print(n,shapes[n].BoundBox,shapes[n].Volume,flush=True)
    A.closeDocument(src.Name)

doc=A.newDocument('FS40')
drive=doc.addObject('App::VarSet','Drive')
drive.addProperty('App::PropertyFloat','Turns','Control','Wheel revolutions; zero to ten, clockwise from the wheel end')
drive.Turns=0
objmap={}
def inst(name,n,x,y,z,typ='',flip=False):
    obj=doc.addObject('Part::Feature',name)
    obj.addProperty('App::PropertyString','PartNumber','Identification')
    obj.PartNumber=n
    obj.Shape=shapes[n].copy()
    base=A.Placement(V(x,y,z),A.Rotation(V(0,0,1),180) if flip else A.Rotation())
    obj.Placement=base
    if typ=='slide':
        obj.setExpression('Placement.Base.x',f'{x} mm + 4 mm * Drive.Turns')
    elif typ=='spin':
        obj.setExpression('Placement.Rotation','rotation(vector(1; 0; 0); Drive.Turns * 360 deg)')
    elif typ=='pin':
        obj.setExpression('Placement','placement(vector(-28 mm; 14 mm * cos(Drive.Turns * 360 deg); 34 mm + 14 mm * sin(Drive.Turns * 360 deg)); rotation(vector(1;0;0); Drive.Turns * 360 deg))')
    objmap[name]=obj.Name
    return obj
inst('P01','P01',0,0,0)
inst('P02L','P02',10,0,8)
inst('P02R','P02',150,0,8,flip=True)
inst('P03','P03',36,0,22,'slide')
inst('P04','P04',-12,0,34,'spin')
inst('P05','P05',-12,0,34,'spin')
inst('P06','P06',32,0,34,'slide')
inst('P07a','P07',10,-21,34)
inst('P07b','P07',10,21,34)
inst('P08L','P08',10,0,34)
inst('P08R','P08',150,0,34,flip=True)
inst('P09','P09',-28,14,34,'pin')
for i,(x,y) in enumerate(itertools.product((16,144),(-33,33))):
    inst('P10'+'abcd'[i],'P10',x,y,0)
for suffix,(y,z) in zip('ab',((-12,25),(12,43))):
    inst('P11'+suffix,'P11',29,y,z,'slide')
doc.recompute()
doc.saveAs(str(sub/'FS40.FCStd'))
(sub/'assembly-map.json').write_text(json.dumps({'driver':{'object':'Drive','property':'Turns','unit':'turns'},'instances':objmap},indent=2),encoding='utf8')
A.closeDocument(doc.Name)
set_initial_view(sub/'FS40.FCStd',(66,0,28),190)
# Verify a fresh copy with no adjacent component files.
with tempfile.TemporaryDirectory(dir=sub) as temp:
    target=Path(temp)/'relocated.FCStd'
    shutil.copy2(sub/'FS40.FCStd',target)
    doc=A.openDocument(str(target))
    report=[]
    for t in (0,1.25,5,4.5,10):
        doc.Drive.Turns=t; doc.recompute()
        shapes={n:doc.getObject(v).Shape for n,v in objmap.items()}
        overlaps=[]
        for a,b in itertools.combinations(shapes,2):
            if not shapes[a].BoundBox.intersect(shapes[b].BoundBox):continue
            common=shapes[a].common(shapes[b])
            vol=abs(common.Volume) if not common.isNull() else 0
            if vol>1e-5:overlaps.append([a,b,round(vol,6)])
        shot={'turns':t,'saddle_x':shapes['P03'].BoundBox.XMin,'saddle_yz':[doc.P03.Placement.Base.y,doc.P03.Placement.Base.z],'saddle_angle_deg':doc.P03.Placement.Rotation.Angle*180/3.141592653589793,'screw_x':shapes['P05'].BoundBox.XMin,'pin_axis_yz':[doc.P09.Placement.Base.y,doc.P09.Placement.Base.z],'positive_volume_mm3':overlaps}
        report.append(shot); print(shot,flush=True)
    A.closeDocument(doc.Name)
(sub/'drive-readings.json').write_text(json.dumps(report,indent=2),encoding='utf8')
