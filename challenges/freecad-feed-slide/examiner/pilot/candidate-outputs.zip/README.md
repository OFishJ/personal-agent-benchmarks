# FS40 双导杆手动丝杠滑台

|文件|用法|
|---|---|
|FS40.FCStd|总装，18 个可选零件实例；打开时为机械零位。|
|assembly-map.json|驱动属性和考生实例名。件号后缀 L、R 表示两端，a、b、c、d 表示重复实例。|
|P02.FCStd、P03.FCStd、P04.FCStd、P09.FCStd|四种自制件的可编辑源模型。|
|make_p03.py|从空白 FreeCAD 文档生成滑鞍。|
|build_assembly.py|用同目录的本轮自制件及 released 中的放行件重建总装与驱动读数。|
|inspection.md、released/|来料测量、处置和最终使用的七种 STEP。|
|drive-readings.json、drive.md|原生输入说明与重开后的实测记录。|
|drawings/FS40-P06.svg、.pdf|法兰螺母零件图，可编辑矢量源文件和 A3 PDF。|
|drawings/FS40-S00.svg、.pdf|零位总装工程图，可编辑矢量源文件和 A3 PDF。|
|gui-evidence.md|GUI 录制原始路径与核对结果。|

## 滑鞍复现

使用 FreeCAD 1.1 自带的 Python 解释器。以提交目录为当前目录运行 `python make_p03.py`，在同目录生成 `P03.FCStd`。指定输出名和横向孔列距可用 `python make_p03.py alternate.FCStd 20`。默认中心距 24 mm，零件树中的 Dimensions → TopPitch 可在保存后继续修改。四个垂直圆柱切除体直接引用这个参数。实际改为 20 后回读，孔轴通过 (10, ±24) 和 (30, ±24)，顶面仍为 Z=28，孔底 Z=22。

如用原装便携版解释器，先导入 FreeCAD，再导入 Part。总装内部已包含所有零件 B-rep 和驱动表达式，独立显示与驱动均由原生 FreeCAD 完成。

两个生成脚本均调用同目录的 `fcstd_view.py`，保存 FreeCAD 的原生视图可见性和初始手轮侧轴测相机。提交的 P03.FCStd 和 FS40.FCStd 均已在本轮工位的图形界面重开确认。
